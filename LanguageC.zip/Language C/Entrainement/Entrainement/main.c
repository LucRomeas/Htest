//
//  main.c
//  Entrainement
//
//  Created by Luc  on 14/11/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>

typedef struct
{
    int degre;
    double tab[];
} polynome;

typedef struct
{
    int x;
    int y;
} point;

void afficher_point(point xy)
{
    printf("( %d ; ", xy.x);
    printf("%d )",xy.y);
}

void afficher_polynome(double tab[], int taille)
{
    for(int i = 0; i < taille; i++)
    {
        if(i==0)
        {
            printf("%lf ; ", tab[i]);
        }
        else
        {
            printf("%lf x^%d ", tab[i], i);
        }
    }
}

void coefficient(polynome a, int exposant)
{
    printf("\n");
    printf("x^%d = %lf", exposant, a.tab[exposant]);
}

polynome lire_polynome()
{
    polynome a;
    printf("Degrès du polynome: ");
    scanf("%d", &a.degre);
    for(int i = 0; i <= a.degre; i++)
    {
        printf("x^%d : ", i);
        scanf("%lf", &a.tab[i]);
    }
    afficher_polynome(a.tab, 4);
    coefficient(a, 3);
    return a;
}




int main(int argc, const char * argv[])
{
    point test = {7,8};
    afficher_point(test);
}
