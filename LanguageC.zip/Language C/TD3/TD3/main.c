//
//  main.c
//  TD3
//
//  Created by Luc  on 26/10/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>
#include <math.h>


// Strcutures
struct _point
{
    double x;
    double y;
};
typedef struct _point point;


// Void
void afficher_point(point p)
{
    printf("(%lf,",p.x);
    printf("%lf)", p.y);
}

double distance(point p1, point p2)
{
    double distance;
    distance = sqrt((p2.x - p1.x)*(p2.x - p1.x) + (p2.y - p1.y)*(p2.y - p1.y));
    return distance;
}
void exo1()
{
    point p1 = {10,5};
    point p2 = {0,3};
    afficher_point(p1);
    printf("\n");
    afficher_point(p2);
    printf("\n");
    printf("Distance entre les points:  %lf", distance(p1, p2));
    printf("\n");
}

typedef struct
{
    int degres;
    double tab[];
    
} polynome;

void afficher_tableau(double tab[], int taille)
{
    for(int i = 0; i<taille; i++)
    {
        printf("%lg", tab[i]);
        if(i==0)
        {
            printf(" ;");
        }
        else
        {
            printf(" x^%d; ",i);

        }
    }
}

polynome lire_polynome()
{
    polynome a;
    printf("Degré du polynome: ");
    scanf("%d", &a.degres);
    for(int i = 0; i< a.degres+1; i++ )
    {
        printf("Degré %d : ",i);
        scanf("%lf", &a.tab[i]);
    }
    afficher_tableau(a.tab, a.degres+1);
    return a;
}

typedef struct
{
    point sup_gauche;
    point sup_droit;
    point inf_gauche;
    point inf_droit;
} rectangle;

void affichage_rectangle(point A, point B, point C, point D)
{
    int longeur = A.x - B.x;
    int largeur = A.y - C.y;
    
    char * matrice_affichage[largeur][longeur];
    // remplissage de la matrice
    for(int i = 0; i < largeur; i++)
    {
        *matrice_affichage[i][0] = '*';
        *matrice_affichage[i][longeur-1] = '*';
    }
    for(int j = 0; j < longeur; j++)
    {
        *matrice_affichage[0][j] = '*';
        *matrice_affichage[largeur-1][j] = '*';
    }
    // afffichage de la matrice
    for(int i = 0; i < largeur; i++)
    {
        for(int j = 0; j < longeur; j++)
        {
            printf("%c",&matrice_affichage[i][j]);
        }

    }
}
    
void exo5()
{
    point A = {0,10};
    point B = {10,10};
    point C = {0,0};
    point D = {10,0};
    affichage_rectangle(A, B, C, D);

}

int main(int argc, const char * argv[])
{
    exo5();
    return 0;
}
