//
//  main.c
//  TD4 Struct
//
//  Created by Luc  on 19/11/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>

/*
typedef struct
{
    double value;
    struct _element* next;
}element;

element* allouer(int valeur)
{
    element* elem = (element*) malloc(sizeof(element));
    elem->value = valeur;
    elem->next = NULL;
    return  elem;
}

element* inserer_en_tete (element* liste, double valeur)
{
    element* premier_elem = allouer(valeur);
    premier_elem->next = liste;
    return premier_elem;
}
*/
int age = 10;
int *pointeur_age = &age;

void multipli(int *valeur)
{
    *valeur *= 3;
}

void decoupe_minute(int *heure, int *min)
{
    *heure = *min / 60;
    *min = *min % 60;
}



int main(int argc, const char * argv[])
{
    
}
