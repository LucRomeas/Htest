//
//  main.c
//  TD4
//
//  Created by Luc  on 15/11/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>
#include "matrice 2D.h"

void afficher_matrice(matrice* p_matrice)
{
    for(int i = 0; i< p_matrice->nb_lignes; i++)
    { for(int j = 0; j<p_matrice->nb_colonnes; j++)
    {
        printf(" %lg ", p_matrice->contenu[i][j]);
    }
        printf("\n");
    }
}


void exo1()
{
    matrice * mat = allouer_matrice2D(2 , 3) ; // cré ation d'une matrice 2 lignes x 3 colonnes
    
    positionner_element (1.0 , mat , 0, 0) ; // mettre l'élé ment 1.0 en position (0 ,0)
    positionner_element (2.0 , mat , 0, 1) ;
    positionner_element (3.0 , mat , 0, 2) ;
    positionner_element (4.0 , mat , 1, 0) ;
    positionner_element (5.0 , mat , 1, 1) ;
    positionner_element (6.0 , mat , 1, 2) ;
    afficher_matrice ( mat );
}

int main(int argc, const char * argv[])
{
    printf("");
    exo1();
}
