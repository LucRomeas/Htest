//
//  matrice 2D.c
//  TD4
//
//  Created by Luc  on 15/11/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include "matrice 2D.h"
#include <stdlib.h>
// PAS de #include <stdio.h>, car les entrées/sorties sont du ressort de l'utilisateur (cf. main.c)
//                            ici on est dans la partie conception de fonctionnalités (d'une bibliothèque)
// si besoin de déboguer ---> utilisez le Débogueur.

/*
 
 [TABLEAU]
 int* tab = malloc(sizzof(*tab)*4);
*(tab+1) = 3 --> 2ème case;
 
 [MATRICE]
 
 
*/
matrice* allouer_matrice2D(int nb_lig, int nb_col)
{
    matrice* tab2D = (matrice*)malloc(sizeof(matrice));
    tab2D->nb_lignes = nb_lig;
    tab2D->nb_colonnes = nb_col;
    tab2D->contenu = (double**)malloc(nb_lig*sizeof(double*));
    for (int i=0; i < nb_lig; i++)
    {
        tab2D->contenu[i] = malloc(nb_col*sizeof(double));
    }
    for (int i=0; i<nb_lig; i++)
    { for(int j=0; j<nb_col;j++)
    { tab2D->contenu[i][j] = 0; }}
    return tab2D;
}

void positionner_element(double valeur, matrice* p_matrice, int ligne, int colonne)
{
    p_matrice->contenu[ligne][colonne] = valeur;
}

double recuperer_element(matrice* p_matrice, int ligne, int colonne)
{
    return p_matrice->contenu[ligne][colonne];
}

void affecter_matrice(matrice* p_matrice, double tab[])
{
    int index_tab = 0;
    for(int i = 0; i< p_matrice->nb_lignes; i++)
    { for(int j = 0; j<p_matrice->nb_colonnes; j++)
    {
        p_matrice->contenu[i][j] = tab[index_tab];
        index_tab++;
    }
    }        
}

void detruire_matrice(matrice* p_matr)
{
    free(p_matr);
}


/*
 TODO:
 Suite des définitions des fonctions correspondant aux déclarations dans le header...
 */
