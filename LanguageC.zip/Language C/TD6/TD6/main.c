//
//  main.c
//  TD6
//
//  Created by Luc  on 26/11/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>
#include <stdbool.h>

void exo1()
{
    char c1 = 'A';
    printf("Caractère %c ; en tant qu'entier, valeur = %d\n", c1, c1);
    // la valeur entière <=> code ASCII du caractère
    char c2 = 'a';
    printf("Caractère %c ; en tant qu'entier, valeur = %d\n", c2, c2);
    
    int e3 = 65 + 1;
    char c3 = (char)e3;
    printf("c3 : %c \n", c3);
    
    int e4 = (int)'A' + 2;
    char c4 = e4;
    printf("c4 : %c \n", c4);
    
    char c5 = 'a' + 3;
    printf("c5 : %c \n", c5);
}

int longeur(const char * chaine)
{
    int i = 0;
    while(chaine[i] != '\0')
    {
        i++;
    }
    return i-1;
}

void exo2()
{
    const char* chaine_test = "Nombres de caractères";
    printf("\n %d Nombre de car:", longeur(chaine_test));
}

bool est_un_palindrome(const char* chaine)
{
    int verif = 0;
    for(int i = 0; i < longeur(chaine)-1; i++)
    {
        if(chaine[i] == chaine[longeur(chaine)-i])
        {
            verif++;
        }
    }
    if(verif == longeur(chaine)-1)
    {
        return true;
    }
    else
    {
        return false;
    }
    
}

void exo3()
{
    const char* mot = "kayak";
    bool pal = est_un_palindrome(mot);
    printf("%d\n", pal);
}

bool est_un_entier(const char* chaine)
{
    int verif = 0;
    for(int i = 0; i < longeur(chaine)-1; i++)
    {
        if (chaine[i]/chaine[i] ==  1)
        {
            verif++;
        }
    }
    if(verif == longeur(chaine)-1)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void exo4()
{
    const char* chaine_test = "12wke";
    bool x = est_un_entier(chaine_test);
    printf("%d\n", x);
}

int main(int argc, const char * argv[])
{
    const char* chaine_test = "12wke";
    int a = chaine_test[4];
    printf("%d\n",a);
    exo4();
}
