//
//  main.c
//  TD5 Struct
//
//  Created by Luc  on 03/12/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>
#include <stdbool.h>

typedef struct _noeud
{
    int valeur;
    struct _noeud * fils_gauche;
    struct _noeud * fils_droite;
}noeud;

noeud* creer_noeud(int valeur)
{
    noeud* element = malloc(sizeof(element));
    element->valeur = valeur;
    element->fils_gauche = NULL;
    element->fils_droite = NULL;
    
    return element;
}

bool associer_fils_gauche(noeud* parent, noeud* enfant)
{
    bool fait = false; // operation pas encore faite
    if( parent != NULL)
    {
        if((parent->fils_gauche == NULL) && (enfant != NULL))
        {
            parent->fils_gauche = enfant;
            fait = true; // operation reussi
        }
    }
    return fait;
}

bool associer_fils_droite(noeud* parent, noeud* enfant)
{
    bool fait = false; // operation pas encore faite
    if( parent != NULL)
    {
        if((parent->fils_droite == NULL) && (enfant != NULL))
        {
            parent->fils_droite = enfant;
            fait = true; // operation reussi
        }
    }
    return fait;
}

bool est_feuille(noeud const* element)
{
    bool feuille = false;
    if(element!=NULL)
    {
        if((element->fils_gauche==NULL)&& (element->fils_droite == NULL))
        {
            feuille = true;
        }
    }
    return feuille;
}

void exo1()
{
    noeud* n1 = creer_noeud(1);
    noeud* n91 = creer_noeud(91);
    noeud* n67 = creer_noeud(67);
    noeud* n14 = creer_noeud(14);
    printf("\n Exo 1; est_feuille : \n");
    printf("n1 est feuille ici : %d \n", est_feuille(n1));
    
    associer_fils_droite(n91, n14);
    associer_fils_gauche(n1, n91);
    associer_fils_droite(n1, n67);
}

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
