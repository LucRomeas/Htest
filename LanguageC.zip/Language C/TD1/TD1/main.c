//
//  main.c
//  TD1
//
//  Created by Luc  on 17/10/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>

void exo1()
{
    printf ("Exo 1\n");
    
    int entier = 12;
    printf ("Le contenu de l'entier est : %d\n", entier );
    
    int entier2 = 34;
    printf ("Les contenus des deux entiers sont respectivement %d et %d\n", entier , entier2 );
}

void exo2()
{
    int var1 = 5;
    int var2 = 17;
    int var3 = 31;
    var3 = var1 * var2;
    var3 = var2 + var3;
    var2+=7;
    var1+=8;
    printf("Var 1 = %d Var 2 = %d  Var 3 = %d \n" ,var1, var2, var3);
}

void exo3()
{
    int entier1;
    int entier2;
    scanf("%d",&entier1);
    scanf("%d",&entier2);
    int somme = entier1 +entier2;
    printf("Somme = %d \n", somme);
    int difference = entier1 - entier2;
    int produit = entier1 * entier2;
    int division = (entier1 / entier2);
    printf("%d %d %d", difference, produit, division);
}

int est_pair(int valeur)
{
    if(valeur % 2 == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int est_multiple(int valeur, int base )
{
    if(valeur % base == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int puissance(int valeur, int puiss)
{
    int resultat = 1;
    for(int i = 1; i <= puiss; i++)
    {
        resultat*= valeur;
    }
    return resultat;
}

void mettre_a_la_puissance(int valeur, int puiss)
{
    int resultat = 1;
    for (int i = 1; i <= puiss; i++)
    {
        resultat*= valeur;
    }
    printf("%d \n", resultat);
}

void exo10()
{
    double tab [] = {1.2 , 3.4 , -5.0, 6.7 , -8.9};
    for(int i =0; i <= sizeof (tab) / sizeof (tab[0])-1; i++)
    {
        printf("%g \n", tab[i]);
    }
}

void exo10_b ()
{
    double tab [] = {1.2 , 3.4 , -5.0, 6.7 , -8.9};
    for(int i =0; i <= sizeof (tab) / sizeof (tab[0])-1; i++)
    {
        tab[i]*=2;
        printf("%g \n", tab[i]);
    }
}

double Fahrenheit_to_Celsius(double valeur)
{
    if(valeur < 0)
    {
        return valeur;
    }
    else
    {
        double val_fahr;
        val_fahr = (valeur - 32) / 1.8;
        return val_fahr;
    }
}
    
double Celsius_to_Fahrenhiet(double valeur)
{
    if(valeur <0)
    {
        return valeur;
    }
    else
    {
        double val_celsius;
        val_celsius = (valeur * 1.8) + 32;
        return val_celsius;
    }
    
}

int main(int argc, const char * argv[])
{
    printf("%g Degré Celsius = %g °F \n",25, Celsius_to_Fahrenhie(26.2));
    return 0;
}
