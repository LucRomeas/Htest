//
//  foret 2D.h
//  TD5 Projet Binome
//
//  Created by Luc  on 20/11/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#ifndef foret_2D_h
#define foret_2D_h

#include <stdio.h>
#include<string.h>


typedef struct
{
    int type;
    int etat;
    int degre;
}cellule;

typedef struct
{
    int nb_lignes;
    int nb_colonnes;
    cellule** contenu;
}matrice_foret;

cellule choix_alea();

cellule ajout_manuel_cel(int valeur);

matrice_foret* creation_foret(int nb_lig, int nb_col);

matrice_foret* creation_copie_foret(int nb_lig, int nb_col);

matrice_foret* remplissage_aleatoire_foret(matrice_foret* foret);

int generation_alea_int(int valeur_max);

void initialise_feu(matrice_foret* foret);

void initialisation_feu_manuel(matrice_foret* foret, int i, int j);

void affiche_foret(matrice_foret* foret);

int nb_voisins_feu(matrice_foret* foret, int indL, int indC);

void matrice_regles(matrice_foret* foret_copie, matrice_foret* foret);

void copie_matrice(matrice_foret* foret_copie, matrice_foret* foret);

#endif /* foret_2D_h */
