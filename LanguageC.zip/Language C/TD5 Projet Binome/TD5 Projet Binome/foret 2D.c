//
//  foret 2D.c
//  TD5 Projet Binome
//
//  Created by Luc  on 20/11/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include "foret 2D.h"
#include <stdlib.h>

matrice_foret* creation_foret(int nb_lig, int nb_col)
{
    matrice_foret* foret = (matrice_foret*)malloc(sizeof(matrice_foret));
    foret->nb_lignes = nb_lig;
    foret->nb_colonnes = nb_col;
    foret->contenu = (cellule**)malloc(nb_lig*sizeof(cellule*));
    for(int i= 0; i<nb_lig; i++)
    {
        foret->contenu[i] = malloc(nb_col*sizeof(cellule));
    }
    return foret;
}

matrice_foret* creation_copie_foret(int nb_lig, int nb_col)
{
    matrice_foret* foret_copie = (matrice_foret*)malloc(sizeof(matrice_foret));
    foret_copie->nb_lignes = nb_lig;
    foret_copie->nb_colonnes = nb_col;
    foret_copie->contenu = (cellule**)malloc(nb_lig*sizeof(cellule*));
    for(int i= 0; i<nb_lig; i++)
    {
        foret_copie->contenu[i] = malloc(nb_col*sizeof(cellule));
    }
    return foret_copie;
}

void copie_matrice(matrice_foret* foret_copie, matrice_foret* foret)
{
    for(int i = 0; i<foret->nb_lignes; i++)
    { for(int j = 0; j<foret->nb_colonnes; j++)
    {
        foret_copie->contenu[i][j] = foret->contenu[i][j];
    }}
}


void matrice_regles(matrice_foret* foret_copie, matrice_foret* foret)  //règles de passage à t+1
{
    copie_matrice(foret_copie, foret);
    for(int i = 0; i<foret_copie->nb_lignes; i++)
    { for(int j = 0; j<foret_copie->nb_colonnes; j++)
    {
        if(foret_copie->contenu[i][j].etat == 1 && foret_copie->contenu[i][j].degre <= 2)  // devient cendre si case en feu
        {
            foret->contenu[i][j].type = 7;
        }
        
        if(foret_copie->contenu[i][j].type == 7)  // si case en cendre à t alors devient cendre eteinte à t+1
        {
            foret->contenu[i][j].type = 8;
            foret->contenu[i][j].etat = 0;
        }
        
        if((foret_copie->contenu[i][j].type == 1 || foret_copie->contenu[i][j].type == 2 || foret_copie->contenu[i][j].type == 6 || foret_copie->contenu[i][j].type == 4) && nb_voisins_feu(foret_copie, i, j) >= 1)
        {
            foret->contenu[i][j].etat = 1;
            foret->contenu[i][j].degre--;
        }
        if(foret_copie->contenu[i][j].etat == 1 && foret_copie->contenu[i][j].degre > 2)  // reduction du degre à 1 si case de deg >2 est en feu 
        {
            foret->contenu[i][j].degre--;
        }
    }}
}

int generation_alea_int(int valeur_max)
{
    int alea = 0;
    do
    {
        alea = 1+rand()/(RAND_MAX/valeur_max);
    }
    while (alea>valeur_max);
    return alea;
}

cellule choix_alea()
{
int alea = generation_alea_int(6);
    cellule cel = {0,0,0};
    if(alea==1)
    {
        cel.type = alea;
        cel.degre= 3;
    }
    if(alea==2)
    {
        cel.type = alea;
        cel.degre= 4;
    }
    if(alea==3)
    {
        cel.type = alea;
        cel.degre= 0;
    }
    if(alea==4)
    {
        cel.type = alea;
        cel.degre= 2;
    }
    if(alea==5)
    {
        cel.type = alea;
        cel.degre= 0;
    }
    if(alea==6)
    {
        cel.type = alea;
        cel.degre= 5;
    }
    return cel;
}

cellule ajout_manuel_cel(int valeur)
{
    cellule cel = {0,0,0};
    if(valeur==1)
    {
        cel.type = valeur;
        cel.degre= 3;
    }
    if(valeur==2)
    {
        cel.type = valeur;
        cel.degre= 4;
    }
    if(valeur==3)
    {
        cel.type = valeur;
        cel.degre= 0;
    }
    if(valeur==4)
    {
        cel.type = valeur;
        cel.degre= 2;
    }
    if(valeur==5)
    {
        cel.type = valeur;
        cel.degre= 0;
    }
    if(valeur==6)
    {
        cel.type = valeur;
        cel.degre= 5;
    }
    return cel;
}

matrice_foret* remplissage_aleatoire_foret(matrice_foret* foret)
{
    for(int i = 0; i< foret->nb_lignes; i++)
    { for(int j = 0; j< foret->nb_colonnes; j++)
    {
        foret->contenu[i][j] = choix_alea();
    }}
        return foret;
}

void initialise_feu(matrice_foret* foret)
{
    int i = generation_alea_int(foret->nb_lignes-1);
    int j = generation_alea_int(foret->nb_colonnes-1);
    if(foret->contenu[i][j].type != 5 && foret->contenu[i][j].type != 3)
    {
        foret->contenu[i][j].etat = 1;
    }
    else
    {
        printf("\nNon propagation du feu car le feu est initialisé sur l'eau ou sur terrain\n");
    }
    printf("Case initiale en feu ( %d ; %d )\n\n", i, j);
    
}

void initialisation_feu_manuel(matrice_foret* foret, int i, int j)
{
    if(foret->contenu[i][j].type != 5 && foret->contenu[i][j].type != 3)
    {
    foret->contenu[i][j].etat = 1;
    }
}

int nb_voisins_feu(matrice_foret* foret, int indL, int indC)
{
    int nb_voisins = 0;
    int ligneduhaut = indL - 1;
    int lignedubas = indL + 1;
    int colonnedegauche = indC - 1;
    int colonnededroite = indC + 1;
    if(indL==0 && indC ==0)  //coin superieur gauche
    {
        if(foret->contenu[indL][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][indC].etat == 1 )
        {
            nb_voisins++;
        }
    }
    
    if(indL==0 && indC == foret->nb_colonnes-1)  //coin superieur droit
    {
        if(foret->contenu[indL][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][indC].etat == 1 )
        {
            nb_voisins++;
        }
    }
    
    if(indL==foret->nb_lignes-1 && indC ==0)  //coin inférieur gauche
    {
        if(foret->contenu[ligneduhaut][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[indL][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
    }
    
    if(indL==foret->nb_lignes-1 && indC==foret->nb_colonnes-1)  //coin inferieur droit
    {
        if(foret->contenu[indL][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
    }
    
    if(indL==0 && indC !=0 && indC != foret->nb_colonnes-1)  //1ère ligne
    {
        if(foret->contenu[indL][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[indL][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
    }
    
    if(indL==foret->nb_lignes-1 && indC !=0 && indC != foret->nb_colonnes-1)  //Dernière ligne
    {
        if(foret->contenu[ligneduhaut][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[indL][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[indL][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
    }
    
    if(indC==0 && indL !=0 && indL!= foret->nb_lignes-1)  //1ère colonne
    {
        if(foret->contenu[lignedubas][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[indL][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
    }
    
    if(indC==foret->nb_colonnes-1 && indL !=0 && indL != foret->nb_lignes-1)  //Dernière colonne
    {
        if(foret->contenu[lignedubas][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[indL][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
    }
    
    if(indC!=0 && indL !=0 && indL != foret->nb_lignes-1 && indC != foret->nb_colonnes-1)  //Cas général
    {
        if(foret->contenu[lignedubas][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[lignedubas][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][indC].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[ligneduhaut][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[indL][colonnedegauche].etat == 1 )
        {
            nb_voisins++;
        }
        if(foret->contenu[indL][colonnededroite].etat == 1 )
        {
            nb_voisins++;
        }
    }
    return nb_voisins;
}
