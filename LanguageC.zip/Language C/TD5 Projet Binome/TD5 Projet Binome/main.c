//
//  main.c
//  TD5 Projet Binome
//
//  Created by Luc  on 20/11/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>
#include "foret 2D.h"

void affiche_foret(matrice_foret* foret)
{
    for(int i = 0; i< foret->nb_lignes; i++)
    {for(int j = 0; j< foret->nb_colonnes; j++)
    {
            if(foret->contenu[i][j].type==1)
                printf(" x ");
            if(foret->contenu[i][j].type==2)
                printf(" * ");
            if(foret->contenu[i][j].type==3)
                printf(" + ");
            if(foret->contenu[i][j].type==4)
                printf("   ");
            if(foret->contenu[i][j].type==5)
                printf(" / ");
            if(foret->contenu[i][j].type==6)
                printf(" # ");
            if(foret->contenu[i][j].type==7)
                printf(" - ");
            if(foret->contenu[i][j].type==8)
                printf(" . ");
    }
        printf("\n");
    }
    printf("\n\n");
}

matrice_foret* remplissage_manuel_foret(matrice_foret* foret)
{
    int type_demande;
    for(int i = 0; i<foret->nb_lignes; i++)
    { for(int j = 0; j<foret->nb_colonnes; j++)
    {
        printf("Case (%d , %d)    Type [1;2;3;4;5] :", i,j);
        scanf("%d", &type_demande);
        foret->contenu[i][j] = ajout_manuel_cel(type_demande);
        }}
    return foret;
}

void simulation()
{
    printf("[Taille de la foret]\n\n");
    
    printf("Longueur : ");
    int longeur_colonnes = 0;
    scanf("%d", &longeur_colonnes);
    
    printf("Largeur : ");
    int largeur_lignes = 0;
    scanf("%d", &largeur_lignes);
    printf("\n");
    matrice_foret* foret = creation_foret(largeur_lignes, longeur_colonnes);
    matrice_foret* foret_copie = creation_copie_foret(largeur_lignes, longeur_colonnes);
    remplissage_aleatoire_foret(foret);
    initialise_feu(foret);
    affiche_foret(foret);
    
    // affichage des générations
    printf("\nNombre de tours ?  ");
    int nb_tours;
    scanf("%d", &nb_tours);
    printf("\n");
    for(int i = 1; i<=nb_tours; i++)
    {
        matrice_regles(foret_copie, foret);
        affiche_foret(foret);
    }
    
}

void simulation_manuelle()
{
    printf("[Taille de la foret]\n\n");
    
    printf("Longueur : ");
    int longeur_colonnes = 0;
    scanf("%d", &longeur_colonnes);
    
    printf("Largeur : ");
    int largeur_lignes = 0;
    scanf("%d", &largeur_lignes);
    printf("\n");
    
    matrice_foret* foret = creation_foret(largeur_lignes, longeur_colonnes);
    matrice_foret* foret_copie = creation_copie_foret(largeur_lignes, longeur_colonnes);
    remplissage_manuel_foret(foret);
    // Affichage matrice de départ
    printf("\nCoordonnées de l'initialisation du feu:\n");
    int i = 0;
    int j = 0;
    printf("\nLigne ");
    scanf("%d", &i);
    printf("Colonne ");
    scanf("%d", &j);
    printf("\n");
    initialisation_feu_manuel(foret, i, j);
    affiche_foret(foret);
    // affichage des générations
    printf("\nNombre de tours ?  ");
    int nb_tours;
    scanf("%d", &nb_tours);
    printf("\n");
    for(int i = 1; i<=nb_tours; i++)
    {
        char choix;
        int valeur_choisie;
        printf("Effectuer des modifications ? [o pour oui ; non]\n");
        scanf("%c", &choix);
        if(choix == 'o' || choix == 'O')
        {
            int lig_modif;
            int col_modif;
            printf("\n\nCase à modifier : ");
            scanf("%d", &lig_modif);
            printf(" ; ");
            scanf("%d", &col_modif);
            
            printf("Modifier le type ?");
            scanf("%c", &choix);
            if(choix == 'o' || choix == 'O')
            {
                printf("\nModifier le type en {0,8} : ");
                scanf("%d", &valeur_choisie);
                foret->contenu[lig_modif][col_modif].type = valeur_choisie;
            }
            
            printf("\n\nModifier l'état ?");
            scanf("%c", &choix);
            if(choix == 'o' || choix == 'O')
            {
                printf("\nModifier l'état en {0,1} : ");
                scanf("%d", &valeur_choisie);
                foret->contenu[lig_modif][col_modif].etat = valeur_choisie;
            }
            
            printf("\n\nModifier le degré\n ?");
            scanf("%c", &choix);
            if(choix == 'o' || choix == 'O')
            {
                printf("\n\nModifier l'état en {0,5} : ");
                scanf("%d", &valeur_choisie);
                foret->contenu[lig_modif][col_modif].degre = valeur_choisie;
            }
        }
        matrice_regles(foret_copie, foret);
        affiche_foret(foret);
    }

    
}


int main(int argc, const char * argv[])
{
    char menu_choisi = ' ';
    do{
        printf("\n[MENU]\n");
        printf("\n\n    A - Remplissage Aléatoire de la foret\n");
        printf("\n\n    B - Remplissage Manuel de la foret\n\n");
        printf("Saisissez votre choix :  ");
        scanf("%c", &menu_choisi);
        if(menu_choisi=='A' || menu_choisi=='a')
        {
            simulation();
        }
        if(menu_choisi=='B' || menu_choisi=='b')
        {
            simulation_manuelle();
        }
    }
    while(menu_choisi != 'A' || menu_choisi !='B' || menu_choisi != 'a' || menu_choisi != 'b');
    

    
}
