//
//  main.c
//  TD3 Struct
//
//  Created by Luc  on 25/10/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>
int min(int a, int b)
{
    if(a<b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

void afficher_tableau(int tab[], int taille)
{
    for(int i = 0; i < taille; i++)
    {
        printf("%d ; ", tab[i]);
    }
}
    

void fussionner(int tab1[], int taille1, int tab2[], int taille2, int tab_fusionner[], int taille_finale)
{
    int i_tab1 = 0;
    int i_tab2 = 0;
    
    for(int i = 0; i < taille_finale; i++)
        {
            if(i_tab1 == taille1)
            {
                tab_fusionner[i_tab2+i_tab1] = tab2[i_tab2];
                i_tab2++;
            }
            if(i_tab2 == taille2)
            {
                tab_fusionner[i_tab2+i_tab1] = tab1[i_tab1];
                i_tab1++;
            }
            else if(tab1[i_tab1] < tab2[i_tab2])
            {
                tab_fusionner[i_tab2+i_tab1] = tab1[i_tab1];
                i_tab1++;
            }
            else
            {
                tab_fusionner[i_tab2+i_tab1] = tab2[i_tab2];
                i_tab2++;
            }
        }
    afficher_tableau(tab_fusionner, taille_finale);
}
    
void tri_fusion(int tab[], int taille)
{
    while(taille >= 1)
    {
        int taille = taille/2;
        int tab1[taille];
        int tab2[taille*2 - taille];
        for (int i = 0; i < taille; i++)
        {
            tab1[i] = tab[i];
        }
        for (int i = taille; i< 2*taille)
        afficher_tableau(tab1, taille);
    }
}


int main(int argc, const char * argv[])
{
    int aa[] = {15,66,70,1012,1100};
    int bb[] = {45,67,89,162};
    int cc[9];
    fussionner(aa,5,bb,4,cc,9);
}

