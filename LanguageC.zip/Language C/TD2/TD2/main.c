//
//  main.c
//  TD2
//
//  Created by Luc  on 24/10/2018.
//  Copyright © 2018 Luc . All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
enum boolean { FALSE, TRUE };  // version en deux lignes
typedef enum boolean boolean;

typedef struct {int a; int b;} rationel; //version en 1 ligne

void afficher(boolean b)
{
    switch (b)
    {
        case TRUE:
            printf("true");
        case FALSE:
            printf("false");
            break;
    }
}

boolean ordonner(int a, int b)
{
    boolean echange = TRUE;
    boolean non_echange = FALSE;
    int var_stockage = 0;
    if(a>b)
    {
        var_stockage = b;
        b = a;
        a = var_stockage;
        return echange;
    }
    else
    {
        var_stockage = 0;
        return non_echange;
    }
}

boolean ordonner_pointeur(int *a, int *b)
{
    boolean echange = TRUE;
    boolean non_echange = FALSE;
    int var_stockage = 0;
    if(*a>*b)
    {
        var_stockage = *b;
        *b = *a;
        *a = var_stockage;
        return echange;
    }
    else
    {
        var_stockage = 0;
        return non_echange;
    }
}

void exo2()
{
    int x = 32;
    int y = 22;
    boolean b = ordonner(x, y);
    afficher(b);
    printf("x=%d , y=%d", x,y);
}

void exo2_pointeur()
{
    int x = 32;
    int y = 22;
    boolean b = ordonner_pointeur(&x, &y);
    afficher(b);
    printf("x=%d , y=%d", x,y);
}

rationel lire_rationel()
{
    rationel valeur;
    scanf("%d %d", &valeur.a, &valeur.b);
    return valeur;
}

void afficher_rationel(rationel x)
{
    printf("%d / %d", x.a, x.b);
}


void exo3()
{
    rationel valeur;
    printf(" ");
    valeur = lire_rationel();
    printf("Le rationnel lu est: ");
    afficher_rationel(valeur);
}

rationel somme_rationnel(rationel num1, rationel num2)
{
    rationel somme;
    // mise au même dénomirateur
    num1.a *= num2.b;
    num2.a *= num1.b;
    num1.b *= num2.b;

    somme.a = num1.a + num2.a;
    somme.b = num1.b;
    return somme;
}

void exo4()
{
    rationel num1;
    rationel num2;
    rationel resultat;
    printf("Rationnel 1 \n:");
    num1 = lire_rationel();
    printf("Rationnel 2 \n:");
    num2 = lire_rationel();
    
    resultat = somme_rationnel(num1, num2);
    afficher_rationel(num1);
    printf(" + ");
    afficher_rationel(num2);
    printf(" = ");
    afficher_rationel(resultat);
}

int exo5()
{
    printf("Exo 5\n");
    
    printf("taille mémoire (en octets) pour stocker un entier : %lu\n", sizeof(int));
    
    printf("\n");
    int *p_entier = malloc(sizeof(*p_entier));  // version plus simple
    if (p_entier != NULL)
    {
        *p_entier = 42;
        printf("contenu de l'élément pointé : %d\n", *p_entier);
    }
    
    printf("\n");
    int *p_elements = malloc(sizeof(*p_elements)*2);
    if (p_elements != NULL)
    {
        *p_elements = 12;
        printf("contenu du premier élément pointé : %d\n", *p_elements);
        printf("contenu du premier élément pointé (version bis) : %d\n", p_elements[0]);
        
        *(p_elements + 1) = 34;
        printf("contenu du second  élément pointé : %d\n", *(p_elements + 1));
        printf("contenu du second  élément pointé (version bis) : %d\n", p_elements[1]);
    }
    return 0;
}

int entier_aleatoire(int valeur_min, int valeur_max)
{
    return valeur_min + rand()%(valeur_max-valeur_min+1);
}

int* generer_tableau_aleatoire(int taille, int valeur_min, int valeur_max)
{
    int* tableau = malloc(sizeof(*tableau)*(taille-1));
    for(int i = 0; i < taille; i++)
    {
        *(tableau+i) = entier_aleatoire(valeur_min, valeur_max);
    }
    return tableau;
}

void afficher_tableau(int tab[], int taille)
{
    for(int i = 0; i<taille; i++)
    {
        printf("%d ; ", tab[i]);
    }
}
void exo6()
{
    int* tableau_aleatoire =  generer_tableau_aleatoire(6, 0, 200);
    afficher_tableau(tableau_aleatoire, 6);
    
}


void permuter(int val_1, int val_2)
{
    int val_stcokage = val_1;
    val_1 = val_2;
    val_2 = val_stcokage;
    
    
}

void exo8()
{
    int val_1 = 10;
    int val_2 = 20;
    int *pointeur_val1 = &val_1;
    int *pointeur_val2 = &val_2;
    permuter(pointeur_val1, pointeur_val2);
    printf("Val 1 : %d \n", *pointeur_val1);
    printf(" Val 2 : %d \n", *pointeur_val2);
}

int index_min_tableau(int taille, int tab[])
{
    int index = 0;
    for(int i = 0; i<taille; i++)
    {
        if(tab[index] > tab[i+1])
        {
            index = (i+1);
        }
    }
    return index;
    
}

int index_max_tableau(int taille, int tab[])
{
    int index = 0;
    for(int i = 0; i<taille; i++)
    {
        if(tab[index] < tab[i+1])
        {
            index = (i+1);
        }
    }
    return index;
    
}

void permuter_min_max_tableau(int tab[], int indexmin, int indexmax)
{
    permuter(indexmin, indexmax);
    tab[indexmin] = tab[indexmax];
}

void exo9()
{
    int* tableau_aleatoire =  generer_tableau_aleatoire(6, 0, 200);
    afficher_tableau(tableau_aleatoire, 6);
    printf("\n\nIndex min: %d \n", index_min_tableau(6, tableau_aleatoire));
    printf("\nIndex max: %d \n\n", index_max_tableau(6, tableau_aleatoire));
    
    permuter_min_max_tableau(tableau_aleatoire, index_min_tableau(6, tableau_aleatoire), index_max_tableau(6, tableau_aleatoire));
    
    printf("\nPermutation :");

    afficher_tableau(tableau_aleatoire, 6);

    printf("\n\nIndex min: %d \n", index_min_tableau(6, tableau_aleatoire));
    printf("\nIndex min: %d \n\n", index_max_tableau(6, tableau_aleatoire));
    
}

int main(int argc, const char * argv[])
{
    printf("\n");
    exo9();
}
